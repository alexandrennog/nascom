-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: nascomercio
-- ------------------------------------------------------
-- Server version	5.5.62

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `produtos`
--

DROP TABLE IF EXISTS `produtos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produtos` (
  `cid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(20) DEFAULT NULL,
  `descricao` varchar(50) DEFAULT NULL,
  `produtoTipo_cid` int(10) unsigned DEFAULT NULL,
  `fornecedor_cid` int(10) unsigned DEFAULT NULL,
  `situacao` varchar(1) DEFAULT NULL,
  `dataInclusao` datetime DEFAULT NULL,
  `valorCompra` decimal(10,2) DEFAULT NULL,
  `valorVenda` decimal(10,2) DEFAULT NULL,
  `imagem` varchar(200) DEFAULT NULL,
  `fabricante_cid` int(10) unsigned DEFAULT NULL,
  `referencia` varchar(20) DEFAULT NULL,
  `estoqueMinimo` int(10) unsigned DEFAULT NULL,
  `cor_cid` int(10) unsigned DEFAULT NULL,
  `grupo_cid` int(10) unsigned DEFAULT NULL,
  `aliquota` varchar(5) DEFAULT NULL,
  `efdUnidadeMedidaCodigo` varchar(3) DEFAULT NULL,
  `efdIntegracao` bit(1) DEFAULT NULL,
  `efdCodigoCategoria` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`cid`),
  KEY `FK_produtos_produtotipos` (`produtoTipo_cid`),
  KEY `FK_produtos_fornecedores` (`fornecedor_cid`),
  KEY `FK_produtos_fabricantes` (`fabricante_cid`),
  CONSTRAINT `FK_produtos_fabricantes` FOREIGN KEY (`fabricante_cid`) REFERENCES `fabricantes` (`cid`),
  CONSTRAINT `FK_produtos_fornecedores` FOREIGN KEY (`fornecedor_cid`) REFERENCES `fornecedores` (`cid`),
  CONSTRAINT `FK_produtos_produtotipos` FOREIGN KEY (`produtoTipo_cid`) REFERENCES `produtotipos` (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=10346 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-19  0:34:45
