-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: nascomercio
-- ------------------------------------------------------
-- Server version	5.5.62

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `v_vendasvendedor`
--

DROP TABLE IF EXISTS `v_vendasvendedor`;
/*!50001 DROP VIEW IF EXISTS `v_vendasvendedor`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_vendasvendedor` AS SELECT 
 1 AS `controle`,
 1 AS `data`,
 1 AS `valorvenda`,
 1 AS `desconto`,
 1 AS `vendedor`,
 1 AS `nome`,
 1 AS `troca`,
 1 AS `defeito`,
 1 AS `vale`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_vendassintetico`
--

DROP TABLE IF EXISTS `v_vendassintetico`;
/*!50001 DROP VIEW IF EXISTS `v_vendassintetico`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_vendassintetico` AS SELECT 
 1 AS `controle`,
 1 AS `data`,
 1 AS `valorTotal`,
 1 AS `desconto`,
 1 AS `vendedor`,
 1 AS `nome`,
 1 AS `troca`,
 1 AS `defeito`,
 1 AS `vale`,
 1 AS `valeEmitido`,
 1 AS `valorvenda`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_estoque`
--

DROP TABLE IF EXISTS `v_estoque`;
/*!50001 DROP VIEW IF EXISTS `v_estoque`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_estoque` AS SELECT 
 1 AS `cid`,
 1 AS `codigo`,
 1 AS `descricao`,
 1 AS `produtoTipo_cid`,
 1 AS `fornecedor_cid`,
 1 AS `situacao`,
 1 AS `dataInclusao`,
 1 AS `valorCompra`,
 1 AS `valorVenda`,
 1 AS `imagem`,
 1 AS `fabricante_cid`,
 1 AS `referencia`,
 1 AS `produtos_cid`,
 1 AS `item`,
 1 AS `caracteristicas_cid`,
 1 AS `valor`,
 1 AS `fabricante`,
 1 AS `fornecedor`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_vendasgrupo`
--

DROP TABLE IF EXISTS `v_vendasgrupo`;
/*!50001 DROP VIEW IF EXISTS `v_vendasgrupo`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_vendasgrupo` AS SELECT 
 1 AS `codigo`,
 1 AS `produto`,
 1 AS `referencia`,
 1 AS `cor`,
 1 AS `grupo`,
 1 AS `cd_grupo`,
 1 AS `controle`,
 1 AS `quantidade`,
 1 AS `valor`,
 1 AS `total_valor`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_vendas`
--

DROP TABLE IF EXISTS `v_vendas`;
/*!50001 DROP VIEW IF EXISTS `v_vendas`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_vendas` AS SELECT 
 1 AS `controle`,
 1 AS `data`,
 1 AS `descricao`,
 1 AS `quantidade`,
 1 AS `valorcompra`,
 1 AS `valorvenda`,
 1 AS `desconto`,
 1 AS `vendedor`,
 1 AS `nome`,
 1 AS `troca`,
 1 AS `fabricante`,
 1 AS `referencia`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_transferencia`
--

DROP TABLE IF EXISTS `v_transferencia`;
/*!50001 DROP VIEW IF EXISTS `v_transferencia`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_transferencia` AS SELECT 
 1 AS `data`,
 1 AS `usuario_nomeCompleto`,
 1 AS `lojaOrigem_razaoSocial`,
 1 AS `lojaDestino_razaoSocial`,
 1 AS `referenciA`,
 1 AS `descricao`,
 1 AS `produtoItem_codigoBarras`,
 1 AS `quantidade`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_vendasfornecedor`
--

DROP TABLE IF EXISTS `v_vendasfornecedor`;
/*!50001 DROP VIEW IF EXISTS `v_vendasfornecedor`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_vendasfornecedor` AS SELECT 
 1 AS `codigo`,
 1 AS `produto`,
 1 AS `referencia`,
 1 AS `cor`,
 1 AS `fornecedor`,
 1 AS `cd_fornecedor`,
 1 AS `controle`,
 1 AS `quantidade`,
 1 AS `valor`,
 1 AS `total_valor`,
 1 AS `data`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_cheques`
--

DROP TABLE IF EXISTS `v_cheques`;
/*!50001 DROP VIEW IF EXISTS `v_cheques`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_cheques` AS SELECT 
 1 AS `cid`,
 1 AS `valor`,
 1 AS `dataemissao`,
 1 AS `datadeposito`,
 1 AS `numero`,
 1 AS `nome`,
 1 AS `banco`,
 1 AS `agencia`,
 1 AS `conta`,
 1 AS `baixado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_balanco`
--

DROP TABLE IF EXISTS `v_balanco`;
/*!50001 DROP VIEW IF EXISTS `v_balanco`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_balanco` AS SELECT 
 1 AS `codigoBarras`,
 1 AS `dataBalanco`,
 1 AS `quantidadeEstoque`,
 1 AS `quantidadeAtualizacao`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_crediario`
--

DROP TABLE IF EXISTS `v_crediario`;
/*!50001 DROP VIEW IF EXISTS `v_crediario`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_crediario` AS SELECT 
 1 AS `codigobarras`,
 1 AS `nome`,
 1 AS `dataemissao`,
 1 AS `dataPagamento`,
 1 AS `valor`,
 1 AS `valorpago`,
 1 AS `valorreceber`,
 1 AS `valortotal`,
 1 AS `datavencimento`,
 1 AS `situacaoCrediario`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_vendaspendentes`
--

DROP TABLE IF EXISTS `v_vendaspendentes`;
/*!50001 DROP VIEW IF EXISTS `v_vendaspendentes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_vendaspendentes` AS SELECT 
 1 AS `controle`,
 1 AS `data`,
 1 AS `produto`,
 1 AS `item`,
 1 AS `quantidade`,
 1 AS `valor`,
 1 AS `codigobarras`,
 1 AS `descricao`,
 1 AS `referencia`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_fechamento`
--

DROP TABLE IF EXISTS `v_fechamento`;
/*!50001 DROP VIEW IF EXISTS `v_fechamento`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_fechamento` AS SELECT 
 1 AS `controle`,
 1 AS `clienteId`,
 1 AS `usuarioId`,
 1 AS `data`,
 1 AS `dinheiro`,
 1 AS `pix`,
 1 AS `cheque`,
 1 AS `chequePre`,
 1 AS `cartaoDebito`,
 1 AS `cartaoCredito`,
 1 AS `crediario`,
 1 AS `parcelas`,
 1 AS `desconto`,
 1 AS `condicao`,
 1 AS `recebido`,
 1 AS `troco`,
 1 AS `total`,
 1 AS `troca`,
 1 AS `vale`,
 1 AS `defeito`,
 1 AS `terminal`,
 1 AS `retirada`,
 1 AS `valeEmitido`,
 1 AS `vendedor`,
 1 AS `caixa`,
 1 AS `crediarioPagamento`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `v_vendasvendedor`
--

/*!50001 DROP VIEW IF EXISTS `v_vendasvendedor`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_vendasvendedor` AS select `vendas`.`controle` AS `controle`,`vendas`.`data` AS `data`,`vendas`.`total` AS `valorvenda`,`vendas`.`desconto` AS `desconto`,`vendas`.`vendedor` AS `vendedor`,`clientes`.`nome` AS `nome`,`vendas`.`troca` AS `troca`,`vendas`.`defeito` AS `defeito`,`vendas`.`vale` AS `vale` from ((`vendas` join `clientes` on((`vendas`.`clienteId` = `clientes`.`cid`))) join `usuarios` on((`vendas`.`vendedor` = `usuarios`.`usuario`))) union all select `vales`.`controle` AS `controle`,`vales`.`data` AS `data`,`vales`.`total` AS `valorvenda`,`vales`.`desconto` AS `desconto`,`vales`.`vendedor` AS `vendedor`,`clientes`.`nome` AS `nome`,`vales`.`troca` AS `troca`,`vales`.`defeito` AS `defeito`,`vales`.`vale` AS `vale` from ((`vales` join `clientes` on((`vales`.`clienteId` = `clientes`.`cid`))) join `usuarios` on((`vales`.`vendedor` = `usuarios`.`usuario`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_vendassintetico`
--

/*!50001 DROP VIEW IF EXISTS `v_vendassintetico`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_vendassintetico` AS select `vendas`.`controle` AS `controle`,`vendas`.`data` AS `data`,(`vendas`.`total` - `vendas`.`troco`) AS `valorTotal`,`vendas`.`desconto` AS `desconto`,`vendas`.`vendedor` AS `vendedor`,`clientes`.`nome` AS `nome`,`vendas`.`troca` AS `troca`,`vendas`.`defeito` AS `defeito`,`vendas`.`vale` AS `vale`,`vendas`.`valeEmitido` AS `valeEmitido`,(((((((`vendas`.`crediario` + `vendas`.`dinheiro`) + `vendas`.`cheque`) + `vendas`.`chequePre`) + `vendas`.`Original`) + `vendas`.`cartaoDebito`) + `vendas`.`cartaoCredito`) - `vendas`.`troco`) AS `valorvenda` from (`vendas` join `clientes` on((`vendas`.`clienteId` = `clientes`.`cid`))) union all select `vales`.`controle` AS `controle`,`vales`.`data` AS `data`,(`vales`.`total` - `vales`.`troco`) AS `valorTotal`,`vales`.`desconto` AS `desconto`,`vales`.`vendedor` AS `vendedor`,`clientes`.`nome` AS `nome`,`vales`.`troca` AS `troca`,`vales`.`defeito` AS `defeito`,`vales`.`vale` AS `vale`,`vales`.`valeEmitido` AS `valeEmitido`,(((((((`vales`.`crediario` + `vales`.`dinheiro`) + `vales`.`cheque`) + `vales`.`chequePre`) + `vales`.`Original`) + `vales`.`cartaoDebito`) + `vales`.`cartaoCredito`) - `vales`.`troco`) AS `valorvenda` from (`vales` join `clientes` on((`vales`.`clienteId` = `clientes`.`cid`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_estoque`
--

/*!50001 DROP VIEW IF EXISTS `v_estoque`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_estoque` AS select `p`.`cid` AS `cid`,`p`.`codigo` AS `codigo`,`p`.`descricao` AS `descricao`,`p`.`produtoTipo_cid` AS `produtoTipo_cid`,`p`.`fornecedor_cid` AS `fornecedor_cid`,`p`.`situacao` AS `situacao`,`p`.`dataInclusao` AS `dataInclusao`,`p`.`valorCompra` AS `valorCompra`,`p`.`valorVenda` AS `valorVenda`,`p`.`imagem` AS `imagem`,`p`.`fabricante_cid` AS `fabricante_cid`,`p`.`referencia` AS `referencia`,`i`.`produtos_cid` AS `produtos_cid`,`i`.`item` AS `item`,`i`.`caracteristicas_cid` AS `caracteristicas_cid`,format(replace(`i`.`valor`,',','.'),0) AS `valor`,`f`.`nome` AS `fabricante`,`o`.`nome` AS `fornecedor` from (((`produtos` `p` join `produtoitem` `i` on((`p`.`cid` = `i`.`produtos_cid`))) join `fabricantes` `f` on((`f`.`cid` = `p`.`fabricante_cid`))) join `fornecedores` `o` on((`o`.`cid` = `p`.`fornecedor_cid`))) where ((`i`.`caracteristicas_cid` = 2) and (`isNumeric`(`i`.`valor`) = 0) and (0 = (select `parametros`.`valor` from `parametros` where (`parametros`.`descricao` = 'IsDecimal')))) union all select `p`.`cid` AS `cid`,`p`.`codigo` AS `codigo`,`p`.`descricao` AS `descricao`,`p`.`produtoTipo_cid` AS `produtoTipo_cid`,`p`.`fornecedor_cid` AS `fornecedor_cid`,`p`.`situacao` AS `situacao`,`p`.`dataInclusao` AS `dataInclusao`,`p`.`valorCompra` AS `valorCompra`,`p`.`valorVenda` AS `valorVenda`,`p`.`imagem` AS `imagem`,`p`.`fabricante_cid` AS `fabricante_cid`,`p`.`referencia` AS `referencia`,`i`.`produtos_cid` AS `produtos_cid`,`i`.`item` AS `item`,`i`.`caracteristicas_cid` AS `caracteristicas_cid`,format(replace(`i`.`valor`,',','.'),2) AS `valor`,`f`.`nome` AS `fabricante`,`o`.`nome` AS `fornecedor` from (((`produtos` `p` join `produtoitem` `i` on((`p`.`cid` = `i`.`produtos_cid`))) join `fabricantes` `f` on((`f`.`cid` = `p`.`fabricante_cid`))) join `fornecedores` `o` on((`o`.`cid` = `p`.`fornecedor_cid`))) where ((`i`.`caracteristicas_cid` = 2) and (`isNumeric`(`i`.`valor`) = 0) and (1 = (select `parametros`.`valor` from `parametros` where (`parametros`.`descricao` = 'IsDecimal')))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_vendasgrupo`
--

/*!50001 DROP VIEW IF EXISTS `v_vendasgrupo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_vendasgrupo` AS select `vp`.`produto` AS `codigo`,`p`.`descricao` AS `produto`,`p`.`referencia` AS `referencia`,`c`.`nome` AS `cor`,`g`.`nome` AS `grupo`,`g`.`cid` AS `cd_grupo`,`vp`.`controle` AS `controle`,`vp`.`quantidade` AS `quantidade`,`vp`.`valor` AS `valor`,(`vp`.`quantidade` * `vp`.`valor`) AS `total_valor` from (((`vendasprodutos` `vp` join `produtos` `p` on((`p`.`codigo` = `vp`.`produto`))) join `categoria` `g` on((`g`.`cid` = `p`.`efdCodigoCategoria`))) join `cor` `c` on((`c`.`cid` = `p`.`cor_cid`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_vendas`
--

/*!50001 DROP VIEW IF EXISTS `v_vendas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_vendas` AS select `vendas`.`controle` AS `controle`,`vendas`.`data` AS `data`,`produtos`.`descricao` AS `descricao`,`vendasprodutos`.`quantidade` AS `quantidade`,`produtos`.`valorCompra` AS `valorcompra`,`vendasprodutos`.`valor` AS `valorvenda`,`vendas`.`desconto` AS `desconto`,`vendas`.`vendedor` AS `vendedor`,`clientes`.`nome` AS `nome`,`vendas`.`troca` AS `troca`,`fabricantes`.`nome` AS `fabricante`,`produtos`.`referencia` AS `referencia` from ((((`vendasprodutos` join `produtos` on((`vendasprodutos`.`produto` = `produtos`.`cid`))) join `vendas` on((`vendasprodutos`.`controle` = `vendas`.`controle`))) join `clientes` on((`vendas`.`clienteId` = `clientes`.`cid`))) join `fabricantes` on((`produtos`.`fabricante_cid` = `fabricantes`.`cid`))) union all select `vales`.`controle` AS `controle`,`vales`.`data` AS `data`,`produtos`.`descricao` AS `descricao`,`valesprodutos`.`quantidade` AS `quantidade`,`produtos`.`valorCompra` AS `valorcompra`,`valesprodutos`.`valor` AS `valorvenda`,`vales`.`desconto` AS `desconto`,`vales`.`vendedor` AS `vendedor`,`clientes`.`nome` AS `nome`,`vales`.`troca` AS `troca`,`fabricantes`.`nome` AS `fabricante`,`produtos`.`referencia` AS `referencia` from ((((`valesprodutos` join `produtos` on((`valesprodutos`.`produto` = `produtos`.`cid`))) join `vales` on((`valesprodutos`.`controle` = `vales`.`controle`))) join `clientes` on((`vales`.`clienteId` = `clientes`.`cid`))) join `fabricantes` on((`produtos`.`fabricante_cid` = `fabricantes`.`cid`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_transferencia`
--

/*!50001 DROP VIEW IF EXISTS `v_transferencia`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_transferencia` AS select `logtransferencia`.`data` AS `data`,`logtransferencia`.`usuario_nomeCompleto` AS `usuario_nomeCompleto`,`logtransferencia`.`lojaOrigem_razaoSocial` AS `lojaOrigem_razaoSocial`,`logtransferencia`.`lojaDestino_razaoSocial` AS `lojaDestino_razaoSocial`,`produtos`.`referencia` AS `referenciA`,`produtos`.`descricao` AS `descricao`,`logtransferencia`.`produtoItem_codigoBarras` AS `produtoItem_codigoBarras`,`logtransferencia`.`quantidade` AS `quantidade` from (`logtransferencia` join `produtos` on((`produtos`.`cid` = `logtransferencia`.`produto_cid`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_vendasfornecedor`
--

/*!50001 DROP VIEW IF EXISTS `v_vendasfornecedor`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_vendasfornecedor` AS select `vp`.`produto` AS `codigo`,`p`.`descricao` AS `produto`,`p`.`referencia` AS `referencia`,`c`.`nome` AS `cor`,`f`.`nome` AS `fornecedor`,`f`.`cid` AS `cd_fornecedor`,`vp`.`controle` AS `controle`,`vp`.`quantidade` AS `quantidade`,`vp`.`valor` AS `valor`,(`vp`.`quantidade` * `vp`.`valor`) AS `total_valor`,`v`.`data` AS `data` from ((((`vendasprodutos` `vp` join `vendas` `v` on((`v`.`controle` = `vp`.`controle`))) join `produtos` `p` on((`p`.`codigo` = `vp`.`produto`))) join `fornecedores` `f` on((`f`.`cid` = `p`.`fornecedor_cid`))) join `cor` `c` on((`c`.`cid` = `p`.`cor_cid`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_cheques`
--

/*!50001 DROP VIEW IF EXISTS `v_cheques`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_cheques` AS select `cheques`.`cid` AS `cid`,`cheques`.`valor` AS `valor`,`cheques`.`dataemissao` AS `dataemissao`,`cheques`.`datadeposito` AS `datadeposito`,`cheques`.`numero` AS `numero`,`clientes`.`nome` AS `nome`,`cheques`.`bancoNome` AS `banco`,`cheques`.`agencia` AS `agencia`,`cheques`.`conta` AS `conta`,`cheques`.`baixado` AS `baixado` from (`cheques` left join `clientes` on((`cheques`.`clienteid` = `clientes`.`cid`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_balanco`
--

/*!50001 DROP VIEW IF EXISTS `v_balanco`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_balanco` AS select `logbalanco`.`produtoItem_codigoBarras` AS `codigoBarras`,`logbalanco`.`data` AS `dataBalanco`,`logbalanco`.`quantidadeEstoque` AS `quantidadeEstoque`,`logbalanco`.`quantidadeAtualizacao` AS `quantidadeAtualizacao` from `logbalanco` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_crediario`
--

/*!50001 DROP VIEW IF EXISTS `v_crediario`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_crediario` AS select `p`.`codigoBarras` AS `codigobarras`,`cli`.`nome` AS `nome`,`p`.`dataemissao` AS `dataemissao`,`p`.`datapagamento` AS `dataPagamento`,`p`.`valor` AS `valor`,`p`.`valorpago` AS `valorpago`,`p`.`valorreceber` AS `valorreceber`,`c`.`valorTotal` AS `valortotal`,`p`.`datavencimento` AS `datavencimento`,`fi`.`situacaoCrediario` AS `situacaoCrediario` from (((`parcelas` `p` join `crediario` `c` on((`c`.`cid` = `p`.`crediarioid`))) join `clientes` `cli` on((`c`.`clienteid` = `cli`.`cid`))) join `clientefinanceiro` `fi` on((`fi`.`cliente_cid` = `cli`.`cid`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_vendaspendentes`
--

/*!50001 DROP VIEW IF EXISTS `v_vendaspendentes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_vendaspendentes` AS select `p`.`controle` AS `controle`,`p`.`data` AS `data`,`pp`.`produto` AS `produto`,`pp`.`item` AS `item`,`pp`.`quantidade` AS `quantidade`,`pp`.`valor` AS `valor`,`pp`.`codigobarras` AS `codigobarras`,`pp`.`descricao` AS `descricao`,`pp`.`referencia` AS `referencia` from (`prevendaproduto` `pp` join `prevendas` `p` on((`pp`.`controle` = `p`.`controle`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_fechamento`
--

/*!50001 DROP VIEW IF EXISTS `v_fechamento`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_fechamento` AS select `vendas`.`controle` AS `controle`,`vendas`.`clienteId` AS `clienteId`,`vendas`.`usuarioId` AS `usuarioId`,`vendas`.`data` AS `data`,`vendas`.`dinheiro` AS `dinheiro`,`vendas`.`Original` AS `pix`,`vendas`.`cheque` AS `cheque`,`vendas`.`chequePre` AS `chequePre`,`vendas`.`cartaoDebito` AS `cartaoDebito`,`vendas`.`cartaoCredito` AS `cartaoCredito`,`vendas`.`crediario` AS `crediario`,`vendas`.`parcelas` AS `parcelas`,`vendas`.`desconto` AS `desconto`,`vendas`.`condicao` AS `condicao`,`vendas`.`recebido` AS `recebido`,`vendas`.`troco` AS `troco`,`vendas`.`total` AS `total`,`vendas`.`troca` AS `troca`,`vendas`.`vale` AS `vale`,`vendas`.`defeito` AS `defeito`,`vendas`.`terminal` AS `terminal`,`vendas`.`retirada` AS `retirada`,`vendas`.`valeEmitido` AS `valeEmitido`,`vendas`.`vendedor` AS `vendedor`,`vendas`.`caixa` AS `caixa`,`vendas`.`crediarioPagamento` AS `crediarioPagamento` from `vendas` union all select `vales`.`controle` AS `controle`,`vales`.`clienteId` AS `clienteId`,`vales`.`usuarioId` AS `usuarioId`,`vales`.`data` AS `data`,`vales`.`dinheiro` AS `dinheiro`,`vales`.`Original` AS `pix`,`vales`.`cheque` AS `cheque`,`vales`.`chequePre` AS `chequePre`,`vales`.`cartaoDebito` AS `cartaoDebito`,`vales`.`cartaoCredito` AS `cartaoCredito`,`vales`.`crediario` AS `crediario`,`vales`.`parcelas` AS `parcelas`,`vales`.`desconto` AS `desconto`,`vales`.`condicao` AS `condicao`,`vales`.`recebido` AS `recebido`,`vales`.`troco` AS `troco`,`vales`.`total` AS `total`,`vales`.`troca` AS `troca`,`vales`.`vale` AS `vale`,`vales`.`defeito` AS `defeito`,`vales`.`terminal` AS `terminal`,`vales`.`retirada` AS `retirada`,`vales`.`valeEmitido` AS `valeEmitido`,`vales`.`vendedor` AS `vendedor`,`vales`.`caixa` AS `caixa`,`vales`.`crediarioPagamento` AS `crediarioPagamento` from `vales` union all select `credpag`.`controle` AS `controle`,`credpag`.`clienteId` AS `clienteId`,`credpag`.`usuarioId` AS `usuarioId`,`credpag`.`data` AS `data`,`credpag`.`dinheiro` AS `dinheiro`,0 AS `pix`,`credpag`.`cheque` AS `cheque`,`credpag`.`chequePre` AS `chequePre`,`credpag`.`cartaoDebito` AS `cartaoDebito`,`credpag`.`cartaoCredito` AS `cartaoCredito`,`credpag`.`crediario` AS `crediario`,`credpag`.`parcelas` AS `parcelas`,`credpag`.`desconto` AS `desconto`,`credpag`.`condicao` AS `condicao`,`credpag`.`recebido` AS `recebido`,`credpag`.`troco` AS `troco`,`credpag`.`total` AS `total`,`credpag`.`troca` AS `troca`,`credpag`.`vale` AS `vale`,`credpag`.`defeito` AS `defeito`,`credpag`.`terminal` AS `terminal`,`credpag`.`retirada` AS `retirada`,`credpag`.`valeEmitido` AS `valeEmitido`,`credpag`.`vendedor` AS `vendedor`,`credpag`.`caixa` AS `caixa`,`credpag`.`crediarioPagamento` AS `crediarioPagamento` from `credpag` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping events for database 'nascomercio'
--

--
-- Dumping routines for database 'nascomercio'
--
/*!50003 DROP FUNCTION IF EXISTS `extract_numbers` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `extract_numbers`(input VARCHAR(255)) RETURNS varchar(255) CHARSET utf8
    DETERMINISTIC
BEGIN
    DECLARE output VARCHAR(255) DEFAULT '';
    DECLARE i INT DEFAULT 1;
    DECLARE len INT;
    DECLARE ch CHAR(1);
    
    SET len = CHAR_LENGTH(input);
    
    WHILE i <= len DO
        SET ch = SUBSTRING(input, i, 1);
        IF ch BETWEEN '0' AND '9' THEN
            SET output = CONCAT(output, ch);
        END IF;
        SET i = i + 1;
    END WHILE;
    
    RETURN output;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `fu_getqtdprods` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fu_getqtdprods`(nomevendedor VARCHAR(30),
    dtIni DATETIME,
    dtFim DATETIME) RETURNS int(11)
BEGIN

DECLARE qtdprodutos INT;
DECLARE qtdvales INT;
DECLARE codProd int;


     SELECT nomeFantasia INTO @nomeloja FROM nascomercio.lojas WHERE cid = 1;

    IF @nomeloja = 'SAPATEK ITAMARATI' THEN
        SET codProd = 4055;
    ELSE
        SET codProd = 911; 
    END IF;

	SELECT sum(quantidade) INTO qtdvales
	FROM nascomercio.vales as v
		inner join nascomercio.valesprodutos as vp ON vp.controle = v.controle
    Where data >= dtIni and data <= dtFim
    and vendedor = ifnull(nomevendedor, vendedor)
	and vp.produto <> codProd;

	SELECT sum(quantidade) INTO qtdprodutos
	FROM nascomercio.vendas as v
		inner join nascomercio.vendasprodutos as vp ON vp.controle = v.controle
    Where data >= dtIni and data <= dtFim
	and vendedor = ifnull(nomevendedor, vendedor)
	and vp.produto <> codProd;

    RETURN ifNull(qtdprodutos,0) + IfNull(qtdvales,0);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `isNumeric` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `isNumeric`(
  input VARCHAR(255)
) RETURNS int(11)
    DETERMINISTIC
RETURN input REGEXP '/[^A-Z]/ig' ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `is_numeric` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `is_numeric`(val VARCHAR(1024)) RETURNS tinyint(1)
    DETERMINISTIC
RETURN val REGEXP '^(-|\\+)?([0-9]+(\\.[0-9]*)?|\\.[0-9]+)$' ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_cursor_product` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_cursor_product`()
BEGIN
    -- Variáveis para armazenar os dados de cada linha
    DECLARE v_nome       VARCHAR(255);
    DECLARE v_unidade    VARCHAR(255);
    DECLARE v_preco      DECIMAL(15,2);
    DECLARE v_tributacao VARCHAR(255);
    DECLARE v_ncm        VARCHAR(255);
    DECLARE v_cest       BIGINT(20);
    DECLARE v_ean_gtin   BIGINT(20);

    -- Controle de fim do cursor
    DECLARE v_fim INT DEFAULT 0;

    -- Declaração do cursor
    DECLARE cur_product CURSOR FOR
        SELECT nome, unidade, preco, tributacao, ncm, cest, EAN_GTIN
        FROM produt;

    -- Handler para fim dos registros
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_fim = 1;

    -- Abre o cursor
    OPEN cur_product;

    loop_cursor: LOOP
        -- Busca o próximo registro
        FETCH cur_product INTO
            v_nome,
            v_unidade,
            v_preco,
            v_tributacao,
            v_ncm,
            v_cest,
            v_ean_gtin;

        -- Sai do loop se não houver mais registros
        IF v_fim = 1 THEN
            LEAVE loop_cursor;
        END IF;

        -- =============================================
        -- Lógica de negócio — adapte conforme necessário
        -- Exemplo: exibe os dados (substituir pelo INSERT/UPDATE real)
        -- =============================================
        SELECT
            v_nome       AS nome,
            v_unidade    AS unidade,
            v_preco      AS preco,
            v_tributacao AS tributacao,
            v_ncm        AS ncm,
            v_cest       AS cest,
            v_ean_gtin   AS EAN_GTIN;
			
			
			-- Insert mínimo em produtos
			INSERT INTO produtos (descricao, situacao, dataInclusao, valorCompra, valorVenda, fabricante_cid, grupo_cid, cor_cid, produtoTipo_cid, fornecedor_cid, referencia, aliquota)
			VALUES (SUBSTR(v_nome, 1, 50), 'A', NOW(), v_preco, v_preco, 158, 1, 744, 1 , 161, 1, 18);




			-- Insert em produtoitem usando o ID gerado acima
			INSERT INTO produtoitem (produtos_cid, item, caracteristicas_cid, valor)
			VALUES (LAST_INSERT_ID(), 0, 1, v_ean_gtin);
            
			INSERT INTO produtoitem (produtos_cid, item, caracteristicas_cid, valor)
			VALUES (LAST_INSERT_ID(), 0, 2, 10);

        -- Exemplo de INSERT em outra tabela
        -- INSERT INTO product_backup (nome, unidade, preco, tributacao, ncm, cest, EAN_GTIN)
        -- VALUES (v_nome, v_unidade, v_preco, v_tributacao, v_ncm, v_cest, v_ean_gtin);

        -- Exemplo de UPDATE baseado em condição
        -- IF v_preco > 100 THEN
        --     UPDATE product SET tributacao = 'CFOP 5102' WHERE nome = v_nome;
        -- END IF;

    END LOOP loop_cursor;

    -- Fecha o cursor
    CLOSE cur_product;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_curva_abc` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_curva_abc`(
    IN p_data_inicio DATE,
    IN p_data_fim    DATE,
    IN p_tipo        CHAR(1)   -- 'V' = por Valor  |  'Q' = por Quantidade
)
BEGIN

    TRUNCATE TABLE curva_abc_resultado;

    IF p_tipo = 'V' THEN

        -- -------------------------------------------------------
        -- CURVA ABC POR VALOR (FATURAMENTO)
        -- -------------------------------------------------------

        -- PASSO 1: uma unica passagem em v_vendas para agrupamento
        -- ERRO 3/4 CORRIGIDO: ORDER BY removido da temp table
        DROP TEMPORARY TABLE IF EXISTS tmp_faturamento;
        CREATE TEMPORARY TABLE tmp_faturamento (
            referencia  VARCHAR(50),
            descricao   VARCHAR(255),
            faturamento DECIMAL(18,4),
            INDEX idx_ref (referencia)
        ) AS
        SELECT
            v.referencia,
            v.descricao,
            SUM(v.quantidade * v.valorvenda) AS faturamento
        FROM v_vendas v
        WHERE v.data BETWEEN p_data_inicio AND p_data_fim
        GROUP BY v.referencia, v.descricao;

        -- PASSO 2: total extraido da temp ja criada — sem segundo scan em v_vendas
        -- ERRO 3 CORRIGIDO: elimina leitura dupla de v_vendas
        SELECT SUM(faturamento)
        INTO   @total_faturamento
        FROM   tmp_faturamento;

        -- PASSO 3: estoque filtrado apenas pelas referencias existentes em tmp_faturamento
        -- ERRO 4 CORRIGIDO: evita agregar todo o catalogo de estoque desnecessariamente
        DROP TEMPORARY TABLE IF EXISTS tmp_estoque;
        CREATE TEMPORARY TABLE tmp_estoque (
            referencia    VARCHAR(50),
            fabricante    VARCHAR(100),
            fornecedor    VARCHAR(100),
            estoque_atual DECIMAL(18,4),
            INDEX idx_ref (referencia)
        ) AS
        SELECT
            e.referencia,
            e.fabricante,
            e.fornecedor,
            SUM(e.valor) AS estoque_atual
        FROM v_estoque e
        WHERE e.referencia IN (SELECT referencia FROM tmp_faturamento)
        GROUP BY e.referencia, e.fabricante, e.fornecedor;

        -- PASSO 4: acumulado inline com ORDER BY garantido somente aqui
        SET @acumulado := 0;

        INSERT INTO `nascomercio`.`curva_abc_resultado`
        (
            `referencia`, `descricao`, `faturamento`,
            `perc_individual`, `perc_acumulado`, `classe_abc`,
            `fabricante`, `fornecedor`, `estoque_atual`
        )
        SELECT
            f.referencia,
            f.descricao,
            f.faturamento,
            ROUND((f.faturamento / @total_faturamento) * 100, 2)                            AS perc_individual,
            ROUND((@acumulado := @acumulado + f.faturamento) / @total_faturamento * 100, 2) AS perc_acumulado,
            CASE
                WHEN (@acumulado / @total_faturamento) <= 0.80 THEN 'A'
                WHEN (@acumulado / @total_faturamento) <= 0.95 THEN 'B'
                ELSE 'C'
            END                                                                             AS classe_abc,
            e.fabricante,
            e.fornecedor,
            COALESCE(e.estoque_atual, 0)                                                    AS estoque_atual
        FROM tmp_faturamento f
        LEFT JOIN tmp_estoque e ON f.referencia = e.referencia
        ORDER BY f.faturamento DESC;

        -- Limpeza
        DROP TEMPORARY TABLE IF EXISTS tmp_faturamento;
        DROP TEMPORARY TABLE IF EXISTS tmp_estoque;

    ELSE

        -- -------------------------------------------------------
        -- CURVA ABC POR QUANTIDADE
        -- -------------------------------------------------------

        -- PASSO 1: uma unica passagem em v_vendas para agrupamento
        -- ERRO 2 CORRIGIDO: comentario duplicado removido
        DROP TEMPORARY TABLE IF EXISTS tmp_quantidade;
        CREATE TEMPORARY TABLE tmp_quantidade (
            referencia  VARCHAR(50),
            descricao   VARCHAR(255),
            total_itens DECIMAL(18,4),
            INDEX idx_ref (referencia)
        ) AS
        SELECT
            v.referencia,
            v.descricao,
            SUM(v.quantidade) AS total_itens
        FROM v_vendas v
        WHERE v.data BETWEEN p_data_inicio AND p_data_fim
        GROUP BY v.referencia, v.descricao;

        -- PASSO 2: total extraido da temp ja criada — sem segundo scan em v_vendas
        SELECT SUM(total_itens)
        INTO   @total_geral
        FROM   tmp_quantidade;

        -- PASSO 3: estoque filtrado apenas pelas referencias existentes em tmp_quantidade
        DROP TEMPORARY TABLE IF EXISTS tmp_estoque;
        CREATE TEMPORARY TABLE tmp_estoque (
            referencia    VARCHAR(50),
            fabricante    VARCHAR(100),
            fornecedor    VARCHAR(100),
            estoque_atual DECIMAL(18,4),
            INDEX idx_ref (referencia)
        ) AS
        SELECT
            e.referencia,
            e.fabricante,
            e.fornecedor,
            SUM(e.valor) AS estoque_atual
        FROM v_estoque e
        WHERE e.referencia IN (SELECT referencia FROM tmp_quantidade)
        GROUP BY e.referencia, e.fabricante, e.fornecedor;

        -- PASSO 4: acumulado inline com ORDER BY garantido somente aqui
        SET @acumulado := 0;

        INSERT INTO `nascomercio`.`curva_abc_resultado`
        (
            `referencia`, `descricao`, `faturamento`,
            `perc_individual`, `perc_acumulado`, `classe_abc`,
            `fabricante`, `fornecedor`, `estoque_atual`
        )
        SELECT
            q.referencia,
            q.descricao,
            q.total_itens                                                              AS faturamento,
            ROUND((q.total_itens / @total_geral) * 100, 2)                            AS perc_individual,
            ROUND((@acumulado := @acumulado + q.total_itens) / @total_geral * 100, 2) AS perc_acumulado,
            CASE
                WHEN (@acumulado / @total_geral) <= 0.80 THEN 'A'
                WHEN (@acumulado / @total_geral) <= 0.95 THEN 'B'
                ELSE 'C'
            END                                                                        AS classe_abc,
            e.fabricante,
            e.fornecedor,
            COALESCE(e.estoque_atual, 0)                                               AS estoque_atual
        FROM tmp_quantidade q
        LEFT JOIN tmp_estoque e ON q.referencia = e.referencia
        ORDER BY q.total_itens DESC;

        -- Limpeza
        DROP TEMPORARY TABLE IF EXISTS tmp_quantidade;
        DROP TEMPORARY TABLE IF EXISTS tmp_estoque;

    END IF;  -- ERRO 1 CORRIGIDO: fechamento do bloco IF/ELSE que estava ausente

    SELECT * FROM nascomercio.curva_abc_resultado;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_curva_abc_fornecedores` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_curva_abc_fornecedores`(
    IN p_data_inicio DATE,
    IN p_data_fim DATE
)
BEGIN
    DECLARE v_total_geral DECIMAL(18,4) DEFAULT 0;

    -- Limpa antes (fora de qualquer fluxo de resultset)
    DROP TEMPORARY TABLE IF EXISTS tmp_vendas_fornecedor;
    DROP TEMPORARY TABLE IF EXISTS tmp_ranking;
    truncate table ranking_resultado_valor;

    CREATE TEMPORARY TABLE tmp_vendas_fornecedor (
        fabricante    VARCHAR(255),
        receita_total DECIMAL(18,4)
    ) ENGINE = MEMORY;

    CREATE TEMPORARY TABLE tmp_ranking (
        fabricante           VARCHAR(255),
        receita_total        DECIMAL(18,4),
        receita_acumulada    DECIMAL(18,4),
        percentual_acumulado DECIMAL(18,6)
    ) ENGINE = MEMORY;

    -- Popula vendas
    INSERT INTO tmp_vendas_fornecedor (fabricante, receita_total)
    SELECT 
        fabricante,
        SUM(quantidade * valorvenda)
    FROM v_vendas
    WHERE data BETWEEN p_data_inicio AND p_data_fim
    GROUP BY fabricante
    ORDER BY SUM(quantidade * valorvenda) DESC;

    -- Total geral em variável local (evita reutilizar a temp table)
    SELECT SUM(receita_total) INTO v_total_geral
    FROM tmp_vendas_fornecedor;

    -- Garante que não seja zero (evita divisão por zero)
    IF v_total_geral IS NULL OR v_total_geral = 0 THEN
        SET v_total_geral = 1;
    END IF;

    -- Calcula acumulado linha a linha
    SET @acumulado := 0;

    INSERT INTO tmp_ranking (fabricante, receita_total, receita_acumulada, percentual_acumulado)
    SELECT
        fabricante,
        receita_total,
        @acumulado := @acumulado + receita_total,
        @acumulado / v_total_geral
    FROM tmp_vendas_fornecedor
    ORDER BY receita_total DESC;

    -- ⚠️ ÚNICO SELECT final — o DataAdapter só pode receber um resultset
	insert into ranking_resultado_valor
    SELECT
        p_data_inicio AS periodo_inicio,
        p_data_fim    AS periodo_fim,
        fabricante,
        ROUND(receita_total, 2) AS total,
        CAST(ROUND(receita_total / v_total_geral * 100, 2) AS DECIMAL(10,2)) AS percentual,
        CAST(ROUND(percentual_acumulado * 100, 2)          AS DECIMAL(10,2)) AS percentual_acumulado,
        CASE
            WHEN percentual_acumulado <= 0.80 THEN 'A - Prioridade Alta'
            WHEN percentual_acumulado <= 0.95 THEN 'B - Prioridade Média'
            ELSE                                   'C - Prioridade Baixa'
        END AS classificacao_abc,
        CASE
            WHEN percentual_acumulado <= 0.80 THEN 'Estoque sempre disponivel | Negociar melhores condicoes'
            WHEN percentual_acumulado <= 0.95 THEN 'Estoque moderado | Buscar prazos melhores'
            ELSE                                   'Reduzir estoque | Negociar devolucao ou troca'
        END AS estrategia_sugerida
    FROM tmp_ranking
    ORDER BY receita_total DESC;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_curva_abc_fornecedores_quantidade` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_curva_abc_fornecedores_quantidade`(
    IN p_data_inicio DATE,
    IN p_data_fim DATE
)
BEGIN
    DROP TEMPORARY TABLE IF EXISTS tmp_vendas_fornecedor;
    DROP TEMPORARY TABLE IF EXISTS tmp_ranking;
	truncate table ranking_resultado_quantidade;
    
    -- Calcula o total de QUANTIDADE vendida por fabricante no período
    CREATE TEMPORARY TABLE tmp_vendas_fornecedor
    ENGINE = MEMORY
    SELECT 
        `fabricante`,
        SUM(`quantidade`) AS quantidade_total
    FROM `v_vendas`
    WHERE `data` BETWEEN p_data_inicio AND p_data_fim
    GROUP BY `fabricante`;
    
    -- Calcula o total geral de quantidade no período
    SET @total_geral = (SELECT SUM(quantidade_total) FROM tmp_vendas_fornecedor);
    
    -- Cria tabela com ranking e percentuais baseados em quantidade
    CREATE TEMPORARY TABLE tmp_ranking
    ENGINE = MEMORY
    SELECT 
        *,
        @qtd_acumulada := @qtd_acumulada + quantidade_total AS quantidade_acumulada,
        @qtd_acumulada / @total_geral AS percentual_acumulado,
        quantidade_total / @total_geral AS percentual_individual
    FROM tmp_vendas_fornecedor
    CROSS JOIN (SELECT @qtd_acumulada := 0) AS vars
    ORDER BY quantidade_total DESC;
    
    -- Corrige o percentual acumulado
    UPDATE tmp_ranking 
    SET percentual_acumulado = quantidade_acumulada / @total_geral;
    
    -- Retorna o resultado final
    insert into ranking_resultado_quantidade
    SELECT 
        p_data_inicio AS periodo_inicio,
        p_data_fim AS periodo_fim,
        `fabricante`,
        `quantidade_total` AS total,
        ROUND(`percentual_individual` * 100, 2) AS percentual,
        ROUND(`percentual_acumulado` * 100, 2) AS percentual_acumulado,
        CASE 
            WHEN `percentual_acumulado` <= 0.80 THEN 'A - Prioridade Alta'
            WHEN `percentual_acumulado` <= 0.95 THEN 'B - Prioridade Média'
            ELSE 'C - Prioridade Baixa'
        END AS classificacao_abc,
        CASE 
            WHEN `percentual_acumulado` <= 0.80 THEN 'Estoque sempre disponivel | Negociar melhores condicoes'
            WHEN `percentual_acumulado` <= 0.95 THEN 'Estoque moderado | Buscar prazos melhores'
            ELSE 'Reduzir estoque | Negociar devolucao ou troca'
        END AS estrategia_sugerida
    FROM tmp_ranking
    ORDER BY total desc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_curva_abc_old` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_curva_abc_old`()
BEGIN

        SET @acumulado := 0;

        truncate table curva_abc_resultado;
    DROP TEMPORARY TABLE IF EXISTS tmp_faturamento;
    CREATE TEMPORARY TABLE tmp_faturamento AS
    SELECT
        v.referencia,
        v.descricao,
        SUM(v.quantidade * v.valorvenda) AS faturamento,
        t.total_faturamento
    FROM v_vendas v
    JOIN (
        SELECT SUM(quantidade * valorvenda) AS total_faturamento
        FROM v_vendas
        WHERE data >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
    ) t ON 1 = 1
    WHERE v.data >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
    GROUP BY v.referencia, v.descricao, t.total_faturamento
    ORDER BY faturamento DESC;

        DROP TEMPORARY TABLE IF EXISTS tmp_ranking;
    CREATE TEMPORARY TABLE tmp_ranking AS
    SELECT
        referencia,
        descricao,
        faturamento,
        total_faturamento,
        @acumulado := @acumulado + faturamento AS acumulado
    FROM tmp_faturamento
    ORDER BY faturamento DESC;

        INSERT INTO `nascomercio`.`curva_abc_resultado`
(`referencia`,
`descricao`,
`faturamento`,
`perc_individual`,
`perc_acumulado`,
`classe_abc`,
`fabricante`,
`fornecedor`,
`estoque_atual`)

    SELECT
        r.referencia,
        r.descricao,
        r.faturamento,
        ROUND((r.faturamento / r.total_faturamento) * 100, 2) AS perc_individual,
        ROUND((r.acumulado   / r.total_faturamento) * 100, 2) AS perc_acumulado,
        CASE
            WHEN (r.acumulado / r.total_faturamento) <= 0.80 THEN 'A'
            WHEN (r.acumulado / r.total_faturamento) <= 0.95 THEN 'B'
            ELSE 'C'
        END AS classe_abc,
        e.fabricante,
        e.fornecedor,
        COALESCE(e.estoque_atual, 0) AS estoque_atual
    FROM tmp_ranking r
    LEFT JOIN (
        SELECT
            referencia,
            fabricante,
            fornecedor,
            SUM(valor) AS estoque_atual
        FROM v_estoque
        GROUP BY referencia, fabricante, fornecedor
    ) e ON r.referencia = e.referencia
    ORDER BY r.faturamento DESC;

        DROP TEMPORARY TABLE IF EXISTS tmp_faturamento;
    DROP TEMPORARY TABLE IF EXISTS tmp_ranking;
    
    SELECT * FROM nascomercio.curva_abc_resultado;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_recuperavendas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_recuperavendas`(IN nomevendedor varchar(30), IN dtIni datetime, IN dtFim datetime)
BEGIN

DROP TEMPORARY TABLE IF EXISTS vendas_range;
CREATE TEMPORARY TABLE vendas_range
AS

SELECT vendedor, (SELECT count(*)
FROM nascomercio.v_vendassintetico
where data >= dtIni and data <= dtFim and valorvenda>0
and vendedor = v.vendedor) as totalvendas, Sum(valorvenda) as valor, fu_getqtdprods(vendedor, dtIni, dtFim) as qtdprod
FROM nascomercio.v_vendassintetico as v
Where data >= dtIni and data <= dtFim
and vendedor = ifnull(nomevendedor, vendedor)
group by vendedor;

select vendedor, COALESCE(totalvendas,0) as totalvendas, valor, qtdprod ,valor/(totalvendas) as ticket ,  qtdprod/(totalvendas) as pa
from vendas_range
where vendedor = ifnull(nomevendedor, vendedor)
and totalvendas > 0
order by valor desc;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_recuperavendasloja` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_recuperavendasloja`(IN dtIni datetime, IN dtFim datetime)
BEGIN

DROP TEMPORARY TABLE IF EXISTS vendas_range;
CREATE TEMPORARY TABLE vendas_range
AS

SELECT (SELECT count(*)
FROM nascomercio.v_vendassintetico
where data >= dtIni and data <= dtFim and valorvenda>0) as totalvendas, Sum(valorvenda)  as valor, fu_getqtdprods(null, dtIni, dtFim) as qtdprod
FROM nascomercio.v_vendassintetico as v
Where data >= dtIni and data <= dtFim;

select (totalvendas) as totalvendas, valor, qtdprod ,valor/(totalvendas) as ticket ,  qtdprod/(totalvendas) as pa
from vendas_range
where totalvendas > 0
order by valor desc;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_controle` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_controle`()
BEGIN

INSERT INTO nascomercio.cobrancas_automaticas (codigocliente, crediarioid, parcelaidid, valor, nome, email, celular, datavencimento)
SELECT c.cid, p.crediarioid, p.cid, p.valor, c.nome as SolicitacaoPagador,  email, concat(dddcel, celular) as celular, DATE_ADD(CURDATE(), INTERVAL 1 DAY) as data_vencimento
FROM nascomercio.crediario as cr 
   inner join clientes as c on cr.clienteid = c.cid
   inner join parcelas as p on p.crediarioid = cr.cid
WHERE DATE_FORMAT(p.datavencimento, '%d/%m/%Y') = DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL 1 DAY), '%d/%m/%Y')
AND dddcel is not null
AND p.valorPago = 0.00;



set @total = (Select MAX(controle) as controle From vendas);

INSERT INTO pix (ID, SolicitacaoPagador, Original, DataHora, Observacao, controle) 
select *,  @total:=@total + 1 as numlinha
from (
SELECT p.cid, c.nome as SolicitacaoPagador, p.valor, DATE_ADD(CURDATE(), INTERVAL 1 DAY) as data_vencimento, 'parcela do crediário'
FROM nascomercio.crediario as cr 
   inner join clientes as c on cr.clienteid = c.cid
   inner join parcelas as p on p.crediarioid = cr.cid
WHERE DATE_FORMAT(p.datavencimento, '%d/%m/%Y') = DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL 1 DAY), '%d/%m/%Y')
AND dddcel is not null
AND p.valorPago = 0.00
) as lista;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-19  0:34:46
