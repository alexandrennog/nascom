-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: nascomercio
-- ------------------------------------------------------
-- Server version	5.5.62

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `vendas`
--

DROP TABLE IF EXISTS `vendas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vendas` (
  `controle` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `clienteId` int(10) unsigned NOT NULL,
  `usuarioId` int(10) unsigned NOT NULL,
  `data` datetime NOT NULL,
  `dinheiro` decimal(10,2) NOT NULL,
  `cheque` decimal(10,2) NOT NULL,
  `chequePre` decimal(10,2) NOT NULL,
  `cartaoDebito` decimal(10,2) NOT NULL,
  `cartaoCredito` decimal(10,2) NOT NULL,
  `crediario` decimal(10,2) NOT NULL,
  `parcelas` int(10) unsigned NOT NULL,
  `desconto` decimal(10,2) NOT NULL,
  `condicao` int(10) unsigned NOT NULL,
  `recebido` decimal(10,2) NOT NULL,
  `troco` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `troca` decimal(10,2) NOT NULL,
  `vale` decimal(10,2) NOT NULL,
  `defeito` decimal(10,2) NOT NULL,
  `terminal` varchar(25) NOT NULL,
  `retirada` decimal(10,2) NOT NULL,
  `valeEmitido` decimal(10,2) DEFAULT NULL,
  `vendedor` varchar(20) DEFAULT NULL,
  `caixa` varchar(20) DEFAULT NULL,
  `crediarioPagamento` decimal(10,2) DEFAULT NULL,
  `ordemServico` varchar(10) DEFAULT NULL,
  `Original` decimal(5,2) NOT NULL DEFAULT '0.00',
  `txID` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`controle`),
  KEY `FK_vendas_1` (`clienteId`),
  KEY `FK_vendas_2` (`usuarioId`),
  CONSTRAINT `FK_vendas_1` FOREIGN KEY (`clienteId`) REFERENCES `clientes` (`cid`),
  CONSTRAINT `FK_vendas_2` FOREIGN KEY (`usuarioId`) REFERENCES `usuarios` (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=90377 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-19  0:34:44
