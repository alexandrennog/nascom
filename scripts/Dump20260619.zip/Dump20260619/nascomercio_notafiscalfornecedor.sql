-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: nascomercio
-- ------------------------------------------------------
-- Server version	5.5.62

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notafiscalfornecedor`
--

DROP TABLE IF EXISTS `notafiscalfornecedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notafiscalfornecedor` (
  `cid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `numero` varchar(20) DEFAULT NULL,
  `serie` varchar(10) DEFAULT NULL,
  `fornecedor_cid` int(10) unsigned DEFAULT NULL,
  `dataEmissao` datetime DEFAULT NULL,
  `dataInclusao` datetime DEFAULT NULL,
  `baseCalculoICMS` decimal(10,2) DEFAULT NULL,
  `valorICMS` decimal(10,2) DEFAULT NULL,
  `baseCalculoICMSSubstituicao` decimal(10,2) DEFAULT NULL,
  `valorICMSSubstituicao` decimal(10,2) DEFAULT NULL,
  `valorTotalIPI` decimal(10,2) DEFAULT NULL,
  `valorTotalProdutos` decimal(10,2) DEFAULT NULL,
  `valorTotalNota` decimal(10,2) DEFAULT NULL,
  `valorBaseIcms` decimal(10,2) DEFAULT NULL,
  `valorBaseIcmsSubstituicao` decimal(10,2) DEFAULT NULL,
  `tipoFluxo_cid` int(10) unsigned DEFAULT NULL,
  `tipoEmissao_cid` int(10) unsigned DEFAULT NULL,
  `tipoNotaFiscal_cid` int(10) unsigned DEFAULT NULL,
  `situacaoNotaFiscal_cid` int(10) unsigned DEFAULT NULL,
  `tipoPagamento_cid` int(10) unsigned DEFAULT NULL,
  `tipoFrete_cid` int(10) unsigned DEFAULT NULL,
  `chaveNotaFiscalEletronica` varchar(50) DEFAULT NULL,
  `dataEntrada` datetime DEFAULT NULL,
  `valorFrete` decimal(10,2) DEFAULT NULL,
  `valorSeguro` decimal(10,2) DEFAULT NULL,
  `valorOutrasDespesas` decimal(10,2) DEFAULT NULL,
  `valorAbatimento` decimal(10,2) DEFAULT NULL,
  `valorTotalPis` decimal(10,2) DEFAULT NULL,
  `valorPisRetidoSubstituicao` decimal(10,2) DEFAULT NULL,
  `valorTotalCofins` decimal(10,2) DEFAULT NULL,
  `valorCofinsRetidoSubstituicao` decimal(10,2) DEFAULT NULL,
  `valorDesconto` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-19  0:34:44
